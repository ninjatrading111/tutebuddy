# Interactive Lookup of Font-Awesome 4 Icons

I got tired of trying to look through the list of tiny little icons on the Font-Awesome Cheatsheet, so I added a bit of CSS and JS to pimp up their page.

I also use this as a local version so I don't have to be online to look up the icons (on the bus or train when I'm developing).

This probably doesn't work on IE, but then, who develops on IE?

Online at: http://btsai.github.io/font_awesome4_cheatsheet/index.html

All of the fonts and css are from here:

* http://fortawesome.github.io/Font-Awesome/cheatsheet/

